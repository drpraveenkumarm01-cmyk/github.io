---
layout: default
title: Publications
permalink: /publications/
---

Full list: **[Google Scholar]({{ site.links.scholar }})**

{% if site.data.publications %}
<ol class="pub-list">
  {% for pub in site.data.publications %}
    <li>
      <div class="pub-title">{{ pub.title }}</div>
      <div class="pub-meta">
        {{ pub.authors }} —
        <em>{{ pub.venue }}</em>{% if pub.volume %} {{ pub.volume }}{% endif %}{% if pub.issue %}({{ pub.issue }}){% endif %}{% if pub.pages %}: {{ pub.pages }}{% endif %}
        ({{ pub.year }})
      </div>
      <div class="pub-links">
        {% if pub.doi %}<a href="https://doi.org/{{ pub.doi }}">DOI</a>{% endif %}
        {% if pub.pubmed %}<a href="{{ pub.pubmed }}">PubMed</a>{% endif %}
        {% if pub.pmc %}<a href="{{ pub.pmc }}">PMC</a>{% endif %}
        {% if pub.pdf %}<a href="{{ pub.pdf }}">PDF</a>{% endif %}
      </div>
    </li>
  {% endfor %}
</ol>
{% endif %}

> Tip: To keep this page updated, edit `_data/publications.yml` (YAML list).  
> If you prefer, you can export citations from Google Scholar (BibTeX) and paste curated items here.
