---
layout: default
title: Home
permalink: /
---

<section class="hero">
  <img class="hero-photo" src="{{ '/assets/img/headshot.png' | relative_url }}" alt="Profile photo">
  <div>
    <h1>{{ site.title }}</h1>
    <div class="hero-tagline">{{ site.tagline }}</div>
    <p>{{ site.description }}</p>

    <div class="button-row">
      <a class="button" href="{{ site.links.scholar }}">Google Scholar</a>
      <a class="button secondary" href="{{ site.links.linkedin }}">LinkedIn</a>
      <a class="button secondary" href="{{ site.links.github }}">GitHub</a>
    </div>

    <ul class="quick-metrics">
      <li><strong>{{ site.scholar.citations }}</strong> citations (Google Scholar)</li>
      <li><strong>{{ site.scholar.interests | size }}</strong> focus areas</li>
    </ul>
  </div>
</section>

<div class="section">
  <h2>Focus areas</h2>
  <div class="card">
    <ul>
      {% for item in site.scholar.interests %}
        <li>{{ item }}</li>
      {% endfor %}
    </ul>
  </div>
</div>

<div class="section">
  <h2>Featured</h2>
  <div class="card">
    <p>
      Featured on <strong>The MedTech Podcast</strong> discussing real‑world data in drug development, the role of AI in healthcare, and the evolving regulatory landscape.
    </p>
    <p class="muted">
      Source: <a href="https://www.linkedin.com/posts/praveen-kumar-m-33a6bab3_nference-medtech-podcast-activity-7293243791937835010-EmoJ">LinkedIn post</a>
    </p>
  </div>
</div>

<div class="section">
  <h2>Selected publications</h2>
  <p>For a complete list, see my <a href="{{ site.links.scholar }}">Google Scholar profile</a>.</p>

  {% assign pubs = site.data.publications | slice: 0, 3 %}
  <ol class="pub-list">
    {% for pub in pubs %}
      <li>
        <div class="pub-title">{{ pub.title }}</div>
        <div class="pub-meta">{{ pub.authors }} — <em>{{ pub.venue }}</em> ({{ pub.year }})</div>
        <div class="pub-links">
          {% if pub.doi %}<a href="https://doi.org/{{ pub.doi }}">DOI</a>{% endif %}
          {% if pub.pubmed %}<a href="{{ pub.pubmed }}">PubMed</a>{% endif %}
          {% if pub.pmc %}<a href="{{ pub.pmc }}">PMC</a>{% endif %}
        </div>
      </li>
    {% endfor %}
  </ol>

  <p><a href="{{ '/publications/' | relative_url }}">View publications →</a></p>
</div>
