Place optional files here (e.g., CV PDF). Then link them from _config.yml.
