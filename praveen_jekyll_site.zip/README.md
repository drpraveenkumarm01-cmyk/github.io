# Personal website (Jekyll + GitHub Pages)

This repo is a simple, fast personal site built with **Jekyll** and hosted for free on **GitHub Pages**.

## Quick start (GitHub Pages)

1. Create a repo:
   - **Recommended (user site):** `YOUR_GITHUB_USERNAME.github.io`
   - Or use any repo name for a project site (then set `baseurl: "/REPO_NAME"` in `_config.yml`).

2. Upload/push the contents of this folder to the repo.

3. In GitHub:
   - **Settings → Pages**
   - **Build and deployment → Source:** Deploy from a branch
   - **Branch:** `main` (or `master`) and **/(root)**

GitHub Pages will build and publish your site.

## Local development (optional)

You need Ruby + Bundler installed.

```bash
bundle install
bundle exec jekyll serve
```

Then open http://localhost:4000

## Custom domain (optional)

1. **Settings → Pages → Custom domain**: enter `yourdomain.com` or `www.yourdomain.com`
2. Configure DNS at your domain registrar/provider (see GitHub Docs):
   - Apex domain (`yourdomain.com`): `A` records to GitHub Pages IPs
   - `www`: `CNAME` to `YOUR_GITHUB_USERNAME.github.io`
3. Back in **Settings → Pages**, enable **Enforce HTTPS** (once available).

## Editing content

- Update site-wide info in `_config.yml`
- Update publications in `_data/publications.yml`
- Replace the photo at `assets/img/headshot.png`
