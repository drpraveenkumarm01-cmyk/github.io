---
layout: default
title: Contact
permalink: /contact/
---

You can reach me via:

- Email: **[your.email@example.com]({{ site.links.email }})**
- LinkedIn: **[Profile]({{ site.links.linkedin }})**
- Google Scholar: **[Publications & citations]({{ site.links.scholar }})**

> Replace the placeholder email in `_config.yml` (under `links.email`).
