---
layout: default
title: About
permalink: /about/
---

I am a physician and clinical pharmacologist, currently serving as **Director & Head of Clinical Sciences at nference**. I’m interested in leveraging **real‑world data/evidence**, **AI/ML**, and **data‑driven insights** to improve clinical development and patient outcomes.

My Google Scholar profile lists my research interests as **health informatics**, **real‑world data → real‑world evidence**, **clinical trials**, and **evidence synthesis**.

If you’d like to collaborate, please reach out via the **Contact** page.
