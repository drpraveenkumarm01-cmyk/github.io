---
layout: default
title: Projects
permalink: /projects/
---

This page is intentionally lightweight. Add (or remove) sections as you like.

<div class="grid-2 section">
  <div class="card">
    <h3>Real‑world data & evidence</h3>
    <p class="muted">Translating real‑world data into insights that can support clinical and regulatory decisions.</p>
  </div>
  <div class="card">
    <h3>Clinical trials & development</h3>
    <p class="muted">Interested in improving trial design, recruitment, and operational efficiency using modern analytics.</p>
  </div>
  <div class="card">
    <h3>Evidence synthesis</h3>
    <p class="muted">Systematic reviews and meta‑analyses to answer clinically relevant questions.</p>
  </div>
  <div class="card">
    <h3>AI in healthcare</h3>
    <p class="muted">Exploring ML‑enabled approaches that are practical, reproducible, and clinically meaningful.</p>
  </div>
</div>

For updates, see my <a href="{{ site.links.linkedin }}">LinkedIn</a>.
